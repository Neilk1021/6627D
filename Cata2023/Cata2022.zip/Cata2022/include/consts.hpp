#include "datastructs.h"
#include "main.h"
#include "pros/apix.h"
#include "pros/adi.h"
#include "pros/adi.hpp"
#include "pros/motors.hpp"
#include "pros/serial.hpp"
using namespace pros;
using namespace pros::c;
using namespace std; 

#ifndef DATA_H
#define DATA_H

extern struct CoreData info;
extern pros::Controller Con;

//extern pros::Motor RightDriveMotor1;
//extern pros::Motor RightDriveMotor2;

//extern pros::motor_group LeftDriveTrain;
//extern pros::motor_group RightDriveTrain;
extern Motor_Group RightDrive;
extern Motor_Group LeftDrive;
extern ADIDigitalIn limitSwitch;
extern Motor IntakeM;
extern Motor CataM;

extern const double ENC_L_DIST;
extern const double ENC_R_DIST;
extern const double WHEEL_RAD;
extern const double FlywheelSpeed;
extern const float ANGLE_SCALE_VAL;
extern const double AutonSpeed;
extern const double IntakeSpeed;
extern const double IntakeSpeedSlowed;

#endif

#ifndef CONSTS
#define CONSTS

#define getDR() (double)R.get_value()
#define getDL() (double)L.get_value()
#define PI 3.14159265358979323846

struct Slew_t{
    double SlewRate, output;
    int prevTime;
    Slew_t(float SlewRate=105);
    double update(double in);
};

#endif